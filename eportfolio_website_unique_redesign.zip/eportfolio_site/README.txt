E-PORTFOLIO WEBSITE

The site has been updated using the uploaded Research Project Outline and Final Version of Research Essay Draft 1.

Files:
- index.html: complete responsive portfolio website.

The site includes:
- Revised research essay with references and a revision explanation.
- Research outline artifact.
- Responsible AI use checklist artifact.
- Audience and purpose notes.
- Reflective process letter (1281 words).

Publish a working public URL for free with GitHub Pages:
1. Sign in at https://github.com/ and create a public repository.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Select Deploy from a branch, choose main and /(root), then Save.
5. Wait for GitHub Pages to show the public URL.

Before submitting:
- Replace [Your Name] and [Semester / Year].
- Review the revised essay carefully and make any changes needed to ensure it reflects your own final decisions.
- Check your instructor's required citation format and confirm all source details.
